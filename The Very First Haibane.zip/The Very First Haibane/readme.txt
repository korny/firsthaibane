This is the complete collection of

  The Very First Haibane

- a webcomic created by archangel from April 30, 2006 to November 24, 2007.

Content:
Scripts - contains the official strips, videos (GIF version) and extrabits.
Goodies - contains wallpapers and additionall art by archangel and some fanart
          created by members of the Old Home Bulletin Board (see below).

Visit:
http://cff.ssw.net/forum/viewtopic.php?t=1713 - the original release thread and discussion
http://firsthaibane.rubychan.de/ - the official website

Disclaimer:
Haibane Renmei is the creation and property of Yoshitoshi ABe and Aureole Secret Factory,
translated and distributed in America by Pioneer and distributed in Europe by MVM.
The authors of this derivative works make no claims of ownership of anything featured
in this story.

Questions:
mailto: murphy rubychan de